#!/bin/bash 

cd data
../src/mpeg2encode input_base_4CIF_96bps_15.par output_base_4CIF_96bps_15.mpg
