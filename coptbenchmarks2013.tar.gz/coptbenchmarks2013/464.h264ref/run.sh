#!/bin/sh

cd data/
../src/benchmark -d foreman_test_encoder_baseline.cfg
