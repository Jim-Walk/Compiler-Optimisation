#!/bin/sh

cd data/
../src/benchmark 20 reference.dat 0 1 100_100_130_cf_a.of
