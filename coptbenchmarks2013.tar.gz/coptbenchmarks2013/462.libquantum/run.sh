#!/bin/sh

cd data/
../src/benchmark 143 25
