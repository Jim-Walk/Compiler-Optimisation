void spec_srand(int seed);
double spec_rand(void);
