#!/bin/bash
cd data
../src/mpeg2decode -b input_base_4CIF_96bps.mpg -o3 output_base_4CIF_96bps_%03d
