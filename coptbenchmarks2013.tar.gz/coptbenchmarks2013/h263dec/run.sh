#!/bin/bash
cd data
../src/benchmark -b input_base_4CIF_96bps.263 -o3 output_base_4CIF_96bps_dec_%03d


